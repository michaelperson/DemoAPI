﻿using PrismMahAppsSample.Infrastructure.Base;

namespace PrismMahAppsSample.Shell.ViewModels
{
    public class HomeTilesViewModel : ViewModelBase
    {
        public HomeTilesViewModel()
        {
            // TODO: 
        }
    }
}
