﻿using Prism.Regions;
using PrismMahAppsSample.Infrastructure.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrismMahAppsSample.Shell.ViewModels
{
    public class RightTitlebarCommandsViewModel : ViewModelBase
    {

    }
}
