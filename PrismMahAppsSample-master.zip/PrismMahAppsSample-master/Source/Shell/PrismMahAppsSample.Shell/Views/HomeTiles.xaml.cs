﻿using System.Windows.Controls;

namespace PrismMahAppsSample.Shell.Views
{
    /// <summary>
    /// Interaktionslogik für HomeTiles.xaml
    /// </summary>
    public partial class HomeTiles : UserControl
    {
        public HomeTiles()
        {
            InitializeComponent();
        }
    }
}
