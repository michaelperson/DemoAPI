﻿using System.Windows.Controls;

namespace PrismMahAppsSample.ModuleB.Views
{
    /// <summary>
    /// Interaktionslogik für RightTitlebarCommands.xaml
    /// </summary>
    public partial class LeftTitlebarCommands : StackPanel
    {
        public LeftTitlebarCommands()
        {
            InitializeComponent();
        }
    }
}
