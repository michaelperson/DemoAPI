﻿using PrismMahAppsSample.Infrastructure.Base;

namespace PrismMahAppsSample.ModuleB.ViewModels
{
    public class LeftTitlebarCommandsViewModel : ViewModelBase
    {

    }
}
