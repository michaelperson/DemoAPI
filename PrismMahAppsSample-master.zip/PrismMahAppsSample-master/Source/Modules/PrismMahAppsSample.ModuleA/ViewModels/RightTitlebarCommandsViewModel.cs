﻿using PrismMahAppsSample.Infrastructure.Base;
using PrismMahAppsSample.Infrastructure.Constants;
using System.Windows.Input;
using Microsoft.Practices.Unity;
using Prism.Commands;

namespace PrismMahAppsSample.ModuleA.ViewModels
{
    public class RightTitlebarCommandsViewModel : ViewModelBase
    {
    }
}
