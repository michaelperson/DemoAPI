﻿using System.Windows.Controls;

namespace PrismMahAppsSample.ModuleA.Views
{
    /// <summary>
    /// Interaktionslogik für RightTitlebarCommands.xaml
    /// </summary>
    public partial class RightTitlebarCommands : StackPanel
    {
        public RightTitlebarCommands()
        {
            InitializeComponent();
        }
    }
}
