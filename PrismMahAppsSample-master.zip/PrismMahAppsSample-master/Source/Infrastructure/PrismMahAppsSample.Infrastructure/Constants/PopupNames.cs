﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrismMahAppsSample.Infrastructure.Constants
{
    public static class PopupNames
    {
        public const string ModuleAPopup = "ModuleAPopup";
    }
}
